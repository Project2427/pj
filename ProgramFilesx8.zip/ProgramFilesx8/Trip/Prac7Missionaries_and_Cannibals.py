from collections import deque
def is_valid_state(state):
    m_left, c_left, m_right, c_right, boat = state
    # Check if the number of missionaries and cannibals is valid on both sides
    if m_left < 0 or c_left < 0 or m_right < 0 or c_right < 0:
        return False
    # Check if missionaries are outnumbered by cannibals on either side
    if (m_left > 0 and m_left < c_left) or (m_right > 0 and m_right < c_right):
        return False
    return True
def is_goal_state(state, goal):
    return state == goal
def get_next_states(state):
    m_left, c_left, m_right, c_right, boat = state
    next_states = []
    if boat == "left":
        for m in range(3):
            for c in range(3):
                if 1 <= m + c <= 2:
                    next_state = (m_left - m, c_left - c, m_right + m, c_right + c, "right")
                    if is_valid_state(next_state):
                        next_states.append(next_state)
    else:
        for m in range(3):
            for c in range(3):
                if 1 <= m + c <= 2:
                    next_state = (m_left + m, c_left + c, m_right - m, c_right - c, "left")
                    if is_valid_state(next_state):
                        next_states.append(next_state)
    return next_states
def solve_missionaries_cannibals():
    initial_state = (3, 3, 0, 0, "left")
    goal_state = (0, 0, 3, 3, "right")
    visited = set()
    queue = deque([(initial_state, [])])
    while queue:
        current_state, path = queue.popleft()
        if is_goal_state(current_state, goal_state):
            return path
        visited.add(current_state)
        for next_state in get_next_states(current_state):
            if next_state not in visited:
                new_path = path + [next_state]
                queue.append((next_state, new_path))
    return None
def print_solution(path):
    for i, state in enumerate(path):
        m_left, c_left, m_right, c_right, boat = state
        print(f"Step {i + 1}:")
        print(f"Left side: {m_left} missionaries, {c_left} cannibals")
        print(f"Right side: {m_right} missionaries, {c_right} cannibals")
        print(f"Boat position: {boat}\n")
if __name__ == "__main__":
    solution_path = solve_missionaries_cannibals()
    if solution_path:
        print("\nSolution found!..\n")
        print_solution(solution_path)
    else:
        print("No solution found.")
print("Praveen Pal 24")

# Solution found!..

# Step 1:
# Left side: 3 missionaries, 1 cannibals
# Right side: 0 missionaries, 2 cannibals
# Boat position: right

# Step 2:
# Left side: 3 missionaries, 2 cannibals
# Right side: 0 missionaries, 1 cannibals
# Boat position: left

# Step 3:
# Left side: 3 missionaries, 0 cannibals
# Right side: 0 missionaries, 3 cannibals
# Boat position: right

# Step 4:
# Left side: 3 missionaries, 1 cannibals
# Right side: 0 missionaries, 2 cannibals
# Boat position: left

# Step 5:
# Left side: 1 missionaries, 1 cannibals
# Right side: 2 missionaries, 2 cannibals
# Boat position: right