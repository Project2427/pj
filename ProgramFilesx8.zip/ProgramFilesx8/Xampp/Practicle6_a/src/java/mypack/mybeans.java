package mypack;

import javax.ejb.Stateless;

@Stateless
public class mybeans {

    public mybeans() {
    }

    public double r2Dollor(double r) {
        return r / 65.65;
    }

    public double d2Rupees(double d) {
        return d * 65.65;
    }
}
