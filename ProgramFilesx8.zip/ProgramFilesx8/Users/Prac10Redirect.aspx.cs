﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Prac10Redirect : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string name = Request.QueryString["Name"];
        string age = Request.QueryString["Age"];
        string email = Request.QueryString["Email"];
        string mobile = Request.QueryString["Mobile"];

        n.Text = name;
        a.Text = age;
        em.Text = email;
        m.Text = mobile;
    }
}