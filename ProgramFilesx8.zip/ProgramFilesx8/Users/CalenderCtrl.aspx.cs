﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CalenderCtrl : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void CalendarPrac_SelectionChanged(object sender, DayRenderEventArgs e)
    {
        DateTime targetDate = new DateTime(DateTime.Now.Year, 9, 29);
        DateTime CurDate = DateTime.Today;

        if (e.Day.Date == targetDate) {
            e.Cell.BackColor = System.Drawing.Color.Red;
            e.Cell.Controls.Add(new LiteralControl("<br>Date"));
        }
        check.Text = e.Day.Date.ToString();
        //check.Text = CurDate.ToString();

    }
}