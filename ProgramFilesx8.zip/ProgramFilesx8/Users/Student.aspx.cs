﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Student : System.Web.UI.Page
{
    string conn = @"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\WebSite\AspPrac\App_Data\PracticalDB.mdf;Integrated Security=True;User Instance=True";
    void Insert()
    {
        using (SqlConnection con = new SqlConnection(conn)) {
            try
                {
                    con.Open();
                    SqlCommand sqlcomm = new SqlCommand("insert into StudTable (rollno, name, class) values (@rno, @n, @c)",con);
                    string Rollno = rollnoTb.Text;
                    string Name = nameTb.Text;
                    string Class = classDDL.SelectedValue.ToString();

                    sqlcomm.Parameters.AddWithValue("@rno",Rollno);
                    sqlcomm.Parameters.AddWithValue("@n",Name);
                    sqlcomm.Parameters.AddWithValue("@c",Class);

                    sqlcomm.ExecuteNonQuery();
                    
                    ack.Text = "Added to DB";
                }
            catch (Exception ex) {
                Response.Write(ex.Message);
            }
                con.Close();
        };
    }

    void Fetch() {
        using(SqlConnection con = new SqlConnection(conn)) {
            try {
                con.Open();
                SqlDataAdapter adp = new SqlDataAdapter("select * from StudTable",con);
                DataTable dataTable = new DataTable();

                adp.Fill(dataTable);
                con.Close();

                StudTable.DataSource = dataTable;
                StudTable.DataBind();
            }
            catch (Exception ex) {
                Response.Write(ex.Message);
            }
            
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        Insert();
        Fetch();
    }
}