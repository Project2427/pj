﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Prac10 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void SubmitButton_Click(object sender, EventArgs e)
    {
        
        if (Page.IsValid) {
            string Name = NameTextBox.Text;
            string Age = AgeTextBox.Text;
            string Mobile = MobileTextBox.Text;
            string Email = EmailTextBox.Text;

            Response.Redirect("Prac10Redirect.aspx?Name="+Name + "&Age=" +Age + "&Mobile="+Mobile + "&Email="+Email);
        }
    }
    protected void ClearButton_Click(object sender, EventArgs e)
    {
        NameTextBox.Text = string.Empty;
        AgeTextBox.Text = string.Empty;
        MobileTextBox.Text = string.Empty;
        EmailTextBox.Text = string.Empty;
    }
}