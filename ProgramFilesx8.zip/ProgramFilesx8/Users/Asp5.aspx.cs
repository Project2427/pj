﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Asp5 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    { 
        CC.Text = "";
        string DDL = CountryDDL.SelectedValue;
        if (DDL == "India")
        {
            CC.Text = "CC +91";
        }
        else if (DDL == "USA") 
        {
            CC.Text = "CC +1";
        }
        else if (DDL == "Dubai")
        {
            CC.Text = "CC +971";
        }
        else if(DDL == "Mexico")
        {
            CC.Text = "+CC 52";
        }

        if(FontSizeRadio1.Checked){
           FontSizeLabel.Font.Size = 15;
        }
        else if (FontSizeRadio2.Checked)
        {
            FontSizeLabel.Font.Size = 20;
        }
        else if (FontSizeRadio3.Checked) {
            FontSizeLabel.Font.Size = 30;
        }

        if (FontPhaseRadio1.Checked)
        {
            FontPhaseLabel.Font.Name = "Calibri";
        }
        else if (FontPhaseRadio2.Checked) {
            FontPhaseLabel.Font.Name = "Arial";
        }
        else if (FontPhaseRadio3.Checked) {
            FontPhaseLabel.Font.Name = "Georgia";
        }
    }
}