﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Asp3 : System.Web.UI.Page
{
    int Num;

    bool PrimeNum() {
        for (int i = 2; i < Num; i++)
        {
            if (Num % i == 0)
            {
                //Output.Text = PrimeCalc.ToString();
                return true;
            }
        }
        return false;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try {
            Num = int.Parse(Number.Text);
        }
        catch (Exception ex) {
        }
        
    }
    protected void fact_Click(object sender, EventArgs e)
    {
        int fact = 1;
        for (int x = 1; x <= Num; x++ ) {
            fact = fact * x;
        }
        Output.Text = fact.ToString();
    }
    protected void moneyConv_Click(object sender, EventArgs e)
    {
        int Dol= Num * 84;
        Output.Text = "$"+Dol.ToString();
    }
    protected void cube_Click(object sender, EventArgs e)
    {
        int Cube = Num * Num * Num;
        Output.Text = Cube.ToString();
    }
    protected void prime_Click(object sender, EventArgs e)
    {
        //Output.Text = "";
        //Output.Text = PrimeNum().ToString();
        if (PrimeNum())
        {
            Output.Text = "Not Prime";
        }
        else {
            Output.Text = "Prime";
        }
    }
}